Includes the following mods:
Water_Wheel_Generator
Windmill_Generator
Cabinets
Large_Statues
